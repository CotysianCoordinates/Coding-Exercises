package examples;

import java.util.Scanner;
import java.util.ArrayList;

public class List {

	public static void main(String[] args) {
		ArrayList<Integer> numbers = new ArrayList<>();
		numbers.add(3);
		numbers.add(2);
		numbers.add(6);
		numbers.add(-1);
		numbers.add(5);
		numbers.add(1);

		System.out.println("The numbers in the range [0, 5]");
		printNumbersInRange(numbers, 0, 5);

		System.out.println("The numbers in the range [3, 10]");
		printNumbersInRange(numbers, 3, 10);
	}

	public static void Names() {
		Scanner scanner = new Scanner(System.in);
		ArrayList<String> nameList = new ArrayList<>();

		while (true) {
			String name = scanner.nextLine();

			if (name.equals("")) {
				break;
			} else {
				nameList.add(name);
			}
		}
		System.out.println(nameList.get(0));
		System.out.println(nameList.get(nameList.size() - 1));

	}

	public static void Numbers() {
		Scanner scanner = new Scanner(System.in);
		ArrayList<Integer> numbers = new ArrayList<>();

		while (true) {
			int number = Integer.valueOf(scanner.nextLine());

			if (number == 0) {
				break;
			} else {
				numbers.add(number);
			}

		}

		System.out.println((numbers.get(1) + numbers.get(2)) + "");
	}

	public static void Numbers2() {
		Scanner scanner = new Scanner(System.in);
		ArrayList<Integer> numbers = new ArrayList<>();

		while (true) {
			int number = Integer.valueOf(scanner.nextLine());

			if (number == -1) {
				break;
			} else {
				numbers.add(number);
			}

		}
		int Greatest = numbers.get(0);

		for (int i = 0; i < numbers.size(); i++) {
			if (Greatest < numbers.get(i)) {
				Greatest = numbers.get(i);
			}
		}
		System.out.println("The greatest number:" + Greatest);

		System.out.print("From where?");
		int Start = Integer.valueOf(scanner.nextLine());
		System.out.print("To where?");
		int End = Integer.valueOf(scanner.nextLine());

		for (int i = Start; i <= End; i++) {
			System.out.println(numbers.get(i));
		}
	}

	public static void Numbers3() {
		Scanner scanner = new Scanner(System.in);
		ArrayList<Integer> numbers = new ArrayList<>();

		while (true) {
			int number = Integer.valueOf(scanner.nextLine());

			if (number == 9999) {
				break;
			} else {
				numbers.add(number);
			}

		}
		int Smallest = numbers.get(0);

		for (int i = 0; i < numbers.size(); i++) {
			if (Smallest > numbers.get(i)) {
				Smallest = numbers.get(i);
			}
		}
		System.out.println("Smallest number:" + Smallest);

		for (int i = 0; i < numbers.size(); i++) {
			if (numbers.get(i) == Smallest) {
				System.out.println("Found at index:" + i);
			}
		}

	}

	public static void printNumbersInRange(ArrayList<Integer> numbers, int lower, int higher) {
		for (int i = 0; i < numbers.size(); i++) {
			if (numbers.get(i) >= lower && numbers.get(i) <= higher) {
				System.out.println(numbers.get(i));
			}
		}
	}
}
