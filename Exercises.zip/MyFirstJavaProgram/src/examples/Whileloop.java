package examples;

import java.util.Scanner;

public class Whileloop {

	public static void main(String[] args) {
		sumof();
	}

	public static void sum() {
		Scanner scanner = new Scanner(System.in);
		int count = 0;
		while (true) {
			System.out.println("Give a number: ");
			int number = Integer.valueOf(scanner.nextLine());
			if (number < 0 || number > 0) {
				count += number;
			} else {
				break;
			}

		}

		System.out.println("Sum of the numbers: " + count);

	}
	public static void count() {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the starting point for the count: ");
		int start = Integer.valueOf(scan.nextLine());
		
		for (int i = start; i <= 100 ; i++) {
			System.out.println(i + "");
			}
		}
		
	public static void count2() {	
		Scanner scann = new Scanner(System.in);
		System.out.print("Enter the Ending point for the count: ");
		int End = Integer.valueOf(scann.nextLine());
		System.out.println("Enter the Starting point for the count: ");
		int Start = Integer.valueOf(scann.nextLine());
		
		for (int i = Start; i <=End ; i++) {
			System.out.println(i + "");
		}
	}
	public static void factorial() {
		Scanner scann = new Scanner(System.in);
		System.out.print("Give a number : ");
		int Fact = Integer.valueOf(scann.nextLine());
		int count = 1;
		for (int i = Fact; i > 0 ; i--) {
			count *= i;
		}
		System.out.println("Factorial: " + count);
		
	}
	public static void sumof() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Give numbers:");
		int Sum = 0;
		int count = 0;
		int Even = 0;
		int Odd = 0;
	while (true) {
		int num = Integer.valueOf(scanner.nextLine());
		
		if (num == -1) {
			break;
		}else if (num % 2 == 0){
			Sum += num;
			count ++;
			Even++;
		}else {
			Sum += num;
			count ++;
			Odd ++;
		}
		
	
	}
	System.out.println("Thx! Bye!");
	System.out.println("Sum:"+ Sum);
	System.out.println("Numbers:" + count);
	double average = ((1.0 * Sum)/(1.0 * count));
	System.out.println("Average:" + average);
	System.out.println("Even: " + Even);
	System.out.println("Odd: " + Odd);
}
}


