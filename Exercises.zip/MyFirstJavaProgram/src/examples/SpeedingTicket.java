
package examples;

import java.util.Scanner;

public class SpeedingTicket {

	public static void main(String[] args) {
		ticket();  //Checks if someone will get a ticket or not based on user input
	}

	public static void ticket() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("How fast were you driving? : ");
		int x = Integer.valueOf(scanner.nextLine());

		if (x > 120) {
			System.out.println("Speeding ticket!");
		} else {
			System.out.println("You were going a safe speed");
			scanner.close();
		}
	}

}
