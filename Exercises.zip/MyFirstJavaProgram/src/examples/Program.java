package examples;

public class Program {
	
	public static void main(String[] args) {
	  countWords("This is the best it can get.");
	  int h = splitWords("This is the best it can get.    ");
	  System.out.println(h);
	}
	
	public static int countWords(String s) {
	      int count = 0;
	      for (int i = 0; i < s.length(); i++)
	      {
	        if (s.charAt(i) == ' ')
	          count++;
	      }
	      System.out.println(count + 1);
	      return count + 1;
	}   
	
	 public static int splitWords(String s) {
		 String[] a = s.split(" ") ;
		 System.out.println(a);
		 
		 return a.length;
	 }
}
			
