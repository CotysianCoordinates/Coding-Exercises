package examples;

public class Print2 {

	public static void main(String[] args) {
		christmasTree(20);
	}

	public static void printStars(int number) {
		for (int i = 0; i < number; i++) {
			System.out.print("*");
		}
		System.out.println("");

	}

	public static void printSpaces(int number) {
		for (int i = 0; i < number; i++) {
			System.out.print(" ");
		}
	}

	public static void printTriangle(int size) {
		for (int i = 1; i <= size; i++) {
			printSpaces(size - i);
			printStars(i);
		}
	}

	public static void christmasTree(int height) {
		int x = 0;
		for (int i = 1; i <= height; i++) {
			printSpaces(height - i);
			printStars(i+x);
			x++;
		}
		for (int i = 0; i < 2; i++) {
		printSpaces(x-2);
		printStars(3);
		}
	}
}