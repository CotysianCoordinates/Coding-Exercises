package examples;

public class examples {
	
	public void message(String myString, int myInt) {
		System.out.println("This is my String: " + myString);
		System.out.println("This is my Int: : " + myInt);
	}
	
	
	public static void main(String[] args) {
        examples E = new examples();
		E.message("hello", 9);
		Donk D = new Donk();
	    D.message2("helo :" , 4);
	    int a = 4;
	    	System.out.println("\n" + a++);
	    System.out.println(a);
	}
	
}
    class Donk extends examples{
	
	public void message2(String myString, int myInt) {
	message(myString, myInt);
	System.out.print("It has been done!");
	}
}

