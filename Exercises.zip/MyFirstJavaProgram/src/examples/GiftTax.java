package examples;

import java.util.Scanner;

public class GiftTax {
	// link to table
	// https://www.vero.fi/en/individuals/property/gifts/gift-tax-calculator/#gifttaxtables
	// Bracket 1 the closest relatives and family
	public static void main(String[] args) {
		Tax();
	}

	public static void Tax() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Value of the gift? ");
		int value = Integer.valueOf(scanner.nextLine());

		if (value >= 5000 && value <= 25000) {
			Taxequation(5000, 100, 8, value);
		} else if (value > 25000 && value <= 55000) {
			Taxequation(25000, 1700, 10, value);
		} else if (value > 55000 && value <= 200000) {
			Taxequation(55000, 4700, 12, value);
		} else if (value > 200000 && value <= 1000000) {
			Taxequation(200000, 22100, 15, value);
		} else if (value > 1000000) {
			Taxequation(100000, 142100, 17, value);
		} else {
			System.out.println("No tax!");
		}
		

	}

	public static void Taxequation(int Lvalue, int LTax, int TRate, int Value) {
		double Tax = (LTax + ((Value - Lvalue) * (TRate / 100.0)));
		System.out.println("Tax:" + Tax);
	}

}
