package examples;

import java.util.Scanner;

public class Methods {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("How many times?");
		int num = Integer.valueOf(scanner.nextLine());
		int i = 0;

		while (i < num) {
			printText();
			i++;
		}

	}

	public static void printText() {
		System.out.println("In a hole in the ground there lived a method");
	}
}
