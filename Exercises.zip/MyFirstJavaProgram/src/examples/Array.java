package examples;

public class Array {
	
	public static void main(String[] args) {
		int[] numbers = {5, 1, 3, 4 , 2};
		printNeatly(numbers);
	}
	
	public static void printNeatly(int[] array) {
		int x = 0;
		while (x < array.length) {
			for (int i = 0; i < array[x] ; i++) {
				System.out.print("*");
			}
			System.out.println("");
			x++;
		}
	}

}
